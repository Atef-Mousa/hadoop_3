#!/bin/bash

exec "$@"